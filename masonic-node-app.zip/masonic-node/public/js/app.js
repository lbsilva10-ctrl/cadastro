// ============================================================
// LOJA MAÇÔNICA — Client-side JS
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  // Auto-dismiss flash messages after 4s
  const flash = document.querySelector('.flash')
  if (flash) {
    setTimeout(() => flash.remove(), 4000)
  }

  // Máscara simples para telefone/whatsapp
  document.querySelectorAll('input[name="telefone"], input[name="whatsapp"]').forEach(input => {
    input.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 11)
      if (v.length > 10) {
        v = v.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3')
      } else if (v.length > 6) {
        v = v.replace(/^(\d{2})(\d{4})(\d*)$/, '($1) $2-$3')
      } else if (v.length > 2) {
        v = v.replace(/^(\d{2})(\d*)$/, '($1) $2')
      }
      e.target.value = v
    })
  })

  // Máscara CEP
  const cepInput = document.querySelector('input[name="endereco_cep"]')
  if (cepInput) {
    cepInput.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 8)
      if (v.length > 5) v = v.replace(/^(\d{5})(\d*)$/, '$1-$2')
      e.target.value = v
    })

    // Busca CEP automaticamente via ViaCEP
    cepInput.addEventListener('blur', async e => {
      const cep = e.target.value.replace(/\D/g, '')
      if (cep.length !== 8) return
      try {
        const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`)
        const data = await res.json()
        if (!data.erro) {
          const f = name => document.querySelector(`[name="${name}"]`)
          if (f('endereco_rua') && !f('endereco_rua').value) f('endereco_rua').value = data.logradouro || ''
          if (f('endereco_bairro') && !f('endereco_bairro').value) f('endereco_bairro').value = data.bairro || ''
          if (f('endereco_cidade') && !f('endereco_cidade').value) f('endereco_cidade').value = data.localidade || ''
          if (f('endereco_estado')) f('endereco_estado').value = data.uf || ''
        }
      } catch (_) {}
    })
  }

  // Confirmação de exclusão com modal nativo
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', e => {
      if (!confirm(form.dataset.confirm)) e.preventDefault()
    })
  })
})
