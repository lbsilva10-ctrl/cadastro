-- =============================================
-- LOJA MAÇÔNICA — Schema do Banco de Dados
-- Execute no Supabase: SQL Editor → New Query
-- =============================================

CREATE TABLE IF NOT EXISTS irmaos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome_completo TEXT NOT NULL,
  nome_maconico TEXT,
  grau INTEGER NOT NULL DEFAULT 1 CHECK (grau BETWEEN 1 AND 33),
  cargo TEXT,
  data_nascimento DATE NOT NULL,
  data_iniciacao DATE,
  data_elevacao DATE,
  data_exaltacao DATE,
  cim TEXT,
  obrv TEXT,
  email TEXT,
  telefone TEXT,
  whatsapp TEXT,
  endereco_rua TEXT,
  endereco_numero TEXT,
  endereco_complemento TEXT,
  endereco_bairro TEXT,
  endereco_cidade TEXT,
  endereco_estado TEXT,
  endereco_cep TEXT,
  situacao TEXT NOT NULL DEFAULT 'ativo'
    CHECK (situacao IN ('ativo','licenciado','suspenso','excluido','benemérito','falecido')),
  observacoes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Atualiza updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_irmaos_updated_at
  BEFORE UPDATE ON irmaos
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at();

-- Índices
CREATE INDEX IF NOT EXISTS idx_irmaos_nome ON irmaos (nome_completo);
CREATE INDEX IF NOT EXISTS idx_irmaos_grau ON irmaos (grau);
CREATE INDEX IF NOT EXISTS idx_irmaos_situacao ON irmaos (situacao);
CREATE INDEX IF NOT EXISTS idx_irmaos_nascimento ON irmaos (data_nascimento);

-- Dados de exemplo
INSERT INTO irmaos (nome_completo, nome_maconico, grau, cargo, data_nascimento, data_iniciacao, cim, telefone, whatsapp, email, endereco_cidade, endereco_estado, situacao)
VALUES
  ('João Pedro Souza',    'Pythagoras', 3, 'Venerável Mestre',   '1965-03-15', '1990-06-20', 'SP-001234', '(11) 99999-0001', '(11) 99999-0001', 'joao@email.com',     'São Paulo',  'SP', 'ativo'),
  ('Carlos Alberto Lima', 'Euclides',   3, 'Primeiro Vigilante', '1970-07-22', '1995-03-10', 'SP-001235', '(11) 99999-0002', '(11) 99999-0002', 'carlos@email.com',   'São Paulo',  'SP', 'ativo'),
  ('Roberto Mendes Costa','Hiram',      2, 'Segundo Vigilante',  '1978-11-30', '2000-09-15', 'SP-001236', '(11) 99999-0003', NULL,              'roberto@email.com',  'Guarulhos',  'SP', 'ativo'),
  ('Marcos Antonio Silva','Sócrates',   1, 'Aprendiz',           '1990-05-08', '2022-04-01', 'SP-001237', '(11) 99999-0004', '(11) 99999-0004', NULL,                 'Mairiporã',  'SP', 'ativo'),
  ('Fernando Oliveira',   'Platão',     3, 'Orador',             '1962-12-25', '1988-01-20', 'SP-001238', '(11) 99999-0005', '(11) 99999-0005', 'fernando@email.com', 'São Paulo',  'SP', 'benemérito');
