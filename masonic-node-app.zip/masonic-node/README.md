# 🔺 Loja Maçônica — Sistema de Gestão do Quadro

Aplicativo web em **Node.js + Express + EJS + Supabase**, com deploy na **Vercel**.

---

## Funcionalidades

- Cadastro completo de irmãos (dados pessoais, maçônicos, contato, endereço)
- Graus do 1º ao 33º com descrições
- Datas de nascimento, iniciação, elevação e exaltação
- Alertas automáticos de aniversariantes do mês
- Busca e filtros por nome, grau e situação
- Ordenação por qualquer coluna
- Links diretos para WhatsApp e telefone
- Busca automática de endereço por CEP (ViaCEP)
- Máscaras de telefone e CEP
- Dashboard com estatísticas do quadro
- Interface responsiva (mobile e desktop)

---

## Estrutura do Projeto

```
masonic-node/
├── server.js                 # Servidor Express principal
├── routes/
│   └── irmaos.js             # Rotas CRUD dos irmãos
├── lib/
│   ├── supabase.js           # Cliente Supabase
│   └── helpers.js            # Funções auxiliares e constantes
├── views/
│   ├── partials/
│   │   ├── header.ejs        # Cabeçalho HTML
│   │   └── footer.ejs        # Rodapé HTML
│   └── irmaos/
│       ├── index.ejs         # Lista / dashboard
│       ├── show.ejs          # Detalhe do irmão
│       └── form.ejs          # Formulário criar/editar
├── public/
│   ├── css/style.css         # Tema maçônico dark/gold
│   └── js/app.js             # JS cliente (máscaras, CEP)
├── supabase-schema.sql       # SQL para criar tabela
├── vercel.json               # Config de deploy
└── .env.example              # Exemplo de variáveis
```

---

## Setup Local

### 1. Instalar dependências

```bash
npm install
```

### 2. Configurar Supabase

1. Acesse [supabase.com](https://supabase.com) e crie um projeto gratuito
2. No **SQL Editor**, execute o conteúdo de `supabase-schema.sql`
3. Em **Project Settings → API**, copie:
   - **Project URL**
   - **anon / public key**

### 3. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Edite `.env`:
```env
SUPABASE_URL=https://SEU_PROJETO.supabase.co
SUPABASE_ANON_KEY=sua_anon_key_aqui
PORT=3000
```

### 4. Rodar localmente

```bash
npm run dev     # com nodemon (recarrega ao salvar)
# ou
npm start       # produção
```

Acesse: **http://localhost:3000**

---

## Deploy na Vercel

### Opção A — Via GitHub (recomendado)

1. Suba o projeto no GitHub
2. Acesse [vercel.com](https://vercel.com) → **New Project** → importe o repositório
3. Em **Environment Variables**, adicione:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
4. Clique em **Deploy** ✅

### Opção B — Via CLI

```bash
npm install -g vercel
vercel login
vercel

# Quando pedir as variáveis de ambiente, informe SUPABASE_URL e SUPABASE_ANON_KEY
```

---

## Campos do Cadastro

| Campo | Descrição |
|---|---|
| Nome Completo | Obrigatório |
| Nome Maçônico | Nome iniciático |
| Grau | 1º ao 33º |
| Cargo | VM, Vigilantes, Orador, etc. |
| Data de Nascimento | Para alertas de aniversário |
| Data de Iniciação | 1º Grau |
| Data de Elevação | 2º Grau |
| Data de Exaltação | 3º Grau |
| CIM | Cadastro Individual do Maçom |
| OBRV | Obediência / Grande Loja |
| Telefone / WhatsApp | Com máscara automática |
| Email | |
| Endereço completo | Preenchimento automático por CEP |
| Situação | Ativo, Licenciado, Suspenso, Excluído, Benemérito, Falecido |
| Observações | Campo livre |

---

*"Reuni o que estava disperso."*
