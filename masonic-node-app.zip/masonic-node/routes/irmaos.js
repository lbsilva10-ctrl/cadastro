const express = require('express')
const router = express.Router()
const supabase = require('../lib/supabase')
const {
  GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS, SITUACAO_COLORS,
  formatDate, formatDateLong, getAge, getBirthdayMonth,
  getGrauLabel, whatsappLink, buildAddress,
} = require('../lib/helpers')

// GET / - lista todos os irmãos
router.get('/', async (req, res) => {
  try {
    const { search = '', grau = '', situacao = '', sort = 'nome_completo', dir = 'asc' } = req.query

    let query = supabase.from('irmaos').select('*')

    if (search) {
      query = query.or(
        `nome_completo.ilike.%${search}%,nome_maconico.ilike.%${search}%,cim.ilike.%${search}%,cargo.ilike.%${search}%`
      )
    }
    if (grau) query = query.eq('grau', parseInt(grau))
    if (situacao) query = query.eq('situacao', situacao)

    const validSorts = ['nome_completo', 'grau', 'data_nascimento', 'situacao', 'cargo']
    const sortField = validSorts.includes(sort) ? sort : 'nome_completo'
    query = query.order(sortField, { ascending: dir !== 'desc' })

    const { data: irmaos, error } = await query

    if (error) throw error

    const hoje = new Date()
    const mesAtual = hoje.getMonth()
    const aniversariantes = (irmaos || []).filter(i => getBirthdayMonth(i.data_nascimento) === mesAtual)

    const ativos = (irmaos || []).filter(i => i.situacao === 'ativo').length
    const grausUnicos = [...new Set((irmaos || []).map(i => i.grau))].sort((a, b) => a - b)

    res.render('irmaos/index', {
      irmaos: irmaos || [],
      aniversariantes,
      total: (irmaos || []).length,
      ativos,
      grausUnicos,
      filters: { search, grau, situacao, sort: sortField, dir },
      GRAU_OPTIONS, SITUACOES, SITUACAO_COLORS,
      formatDate, getAge, getGrauLabel,
      helpers: { formatDate, getAge, getGrauLabel, whatsappLink, buildAddress, formatDateLong },
    })
  } catch (err) {
    console.error(err)
    res.render('irmaos/index', {
      irmaos: [], aniversariantes: [], total: 0, ativos: 0, grausUnicos: [],
      filters: {}, GRAU_OPTIONS, SITUACOES, SITUACAO_COLORS,
      error: err.message || 'Erro ao carregar dados do Supabase',
      helpers: { formatDate, getAge, getGrauLabel, whatsappLink, buildAddress, formatDateLong },
    })
  }
})

// GET /novo - form novo
router.get('/novo', (req, res) => {
  res.render('irmaos/form', {
    irmao: null, action: '/irmaos', method: 'POST', title: 'Novo Irmão',
    GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS, errors: [],
  })
})

// POST / - criar
router.post('/', async (req, res) => {
  const data = sanitize(req.body)
  const errors = validate(data)
  if (errors.length) {
    return res.render('irmaos/form', {
      irmao: data, action: '/irmaos', method: 'POST', title: 'Novo Irmão',
      GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS, errors,
    })
  }
  try {
    const { error } = await supabase.from('irmaos').insert(data)
    if (error) throw error
    res.redirect('/irmaos?flash=Irmão+cadastrado+com+sucesso!&flashType=success')
  } catch (err) {
    res.render('irmaos/form', {
      irmao: data, action: '/irmaos', method: 'POST', title: 'Novo Irmão',
      GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS,
      errors: [{ msg: err.message }],
    })
  }
})

// GET /:id - detalhe
router.get('/:id', async (req, res) => {
  try {
    const { data: irmao, error } = await supabase
      .from('irmaos').select('*').eq('id', req.params.id).single()
    if (error || !irmao) return res.redirect('/irmaos?flash=Irmão+não+encontrado&flashType=error')
    res.render('irmaos/show', {
      irmao, SITUACAO_COLORS,
      helpers: { formatDate, formatDateLong, getAge, getGrauLabel, whatsappLink, buildAddress },
    })
  } catch (err) {
    res.redirect('/irmaos')
  }
})

// GET /:id/editar - form edição
router.get('/:id/editar', async (req, res) => {
  try {
    const { data: irmao, error } = await supabase
      .from('irmaos').select('*').eq('id', req.params.id).single()
    if (error || !irmao) return res.redirect('/irmaos')
    res.render('irmaos/form', {
      irmao, action: `/irmaos/${irmao.id}?_method=PUT`, method: 'POST',
      title: 'Editar Irmão', GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS, errors: [],
    })
  } catch (err) {
    res.redirect('/irmaos')
  }
})

// PUT /:id - atualizar
router.put('/:id', async (req, res) => {
  const data = sanitize(req.body)
  const errors = validate(data)
  if (errors.length) {
    return res.render('irmaos/form', {
      irmao: { ...data, id: req.params.id },
      action: `/irmaos/${req.params.id}?_method=PUT`, method: 'POST',
      title: 'Editar Irmão', GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS, errors,
    })
  }
  try {
    const { error } = await supabase.from('irmaos').update(data).eq('id', req.params.id)
    if (error) throw error
    res.redirect(`/irmaos/${req.params.id}?flash=Dados+atualizados+com+sucesso!&flashType=success`)
  } catch (err) {
    res.render('irmaos/form', {
      irmao: { ...data, id: req.params.id },
      action: `/irmaos/${req.params.id}?_method=PUT`, method: 'POST',
      title: 'Editar Irmão', GRAU_OPTIONS, CARGOS, SITUACOES, ESTADOS,
      errors: [{ msg: err.message }],
    })
  }
})

// DELETE /:id - excluir
router.delete('/:id', async (req, res) => {
  try {
    const { error } = await supabase.from('irmaos').delete().eq('id', req.params.id)
    if (error) throw error
    res.redirect('/irmaos?flash=Irmão+removido+do+quadro&flashType=success')
  } catch (err) {
    res.redirect(`/irmaos?flash=${encodeURIComponent(err.message)}&flashType=error`)
  }
})

// --- Helpers internos ---
function sanitize(body) {
  return {
    nome_completo: (body.nome_completo || '').trim(),
    nome_maconico: (body.nome_maconico || '').trim() || null,
    grau: parseInt(body.grau) || 1,
    cargo: (body.cargo || '').trim() || null,
    data_nascimento: body.data_nascimento || null,
    data_iniciacao: body.data_iniciacao || null,
    data_elevacao: body.data_elevacao || null,
    data_exaltacao: body.data_exaltacao || null,
    cim: (body.cim || '').trim() || null,
    obrv: (body.obrv || '').trim() || null,
    email: (body.email || '').trim() || null,
    telefone: (body.telefone || '').trim() || null,
    whatsapp: (body.whatsapp || '').trim() || null,
    endereco_rua: (body.endereco_rua || '').trim() || null,
    endereco_numero: (body.endereco_numero || '').trim() || null,
    endereco_complemento: (body.endereco_complemento || '').trim() || null,
    endereco_bairro: (body.endereco_bairro || '').trim() || null,
    endereco_cidade: (body.endereco_cidade || '').trim() || null,
    endereco_estado: (body.endereco_estado || '').trim() || null,
    endereco_cep: (body.endereco_cep || '').trim() || null,
    situacao: body.situacao || 'ativo',
    observacoes: (body.observacoes || '').trim() || null,
  }
}

function validate(data) {
  const errors = []
  if (!data.nome_completo) errors.push({ field: 'nome_completo', msg: 'Nome completo é obrigatório' })
  if (!data.data_nascimento) errors.push({ field: 'data_nascimento', msg: 'Data de nascimento é obrigatória' })
  return errors
}

module.exports = router
