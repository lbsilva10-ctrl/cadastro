require('dotenv').config()
const express = require('express')
const methodOverride = require('method-override')
const path = require('path')

const irmaosRouter = require('./routes/irmaos')

const app = express()
const PORT = process.env.PORT || 3000

// View engine
app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))

// Middleware
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
app.use(methodOverride('_method'))
app.use(express.static(path.join(__dirname, 'public')))

// Flash messages via simple middleware
app.use((req, res, next) => {
  res.locals.flash = req.query.flash || null
  res.locals.flashType = req.query.flashType || 'success'
  next()
})

// Routes
app.get('/', (req, res) => res.redirect('/irmaos'))
app.use('/irmaos', irmaosRouter)

// 404
app.use((req, res) => {
  res.status(404).render('404')
})

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).render('error', { message: err.message })
})

app.listen(PORT, () => {
  console.log(`🔺 Loja Maçônica rodando em http://localhost:${PORT}`)
})

module.exports = app
